#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日本大学招生信息自动监控脚本
功能：检测官网 HTML 内容变化，使用 DeepSeek AI 智能判断要項相关的重大变化
"""

import os
import re
import json
import time
import logging
import hashlib
from datetime import datetime
from typing import Dict, Optional
import requests
import pandas as pd
from dotenv import load_dotenv
from litellm import completion

# 加载环境变量
load_dotenv()

# ========== 配置区 ==========
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_API_BASE = os.getenv("DEEPSEEK_API_BASE", "https://api.deepseek.com")
DINGTALK_WEBHOOK = os.getenv("DINGTALK_WEBHOOK", "")
CSV_FILE_PATH = os.getenv("CSV_FILE_PATH", "零和备考信息表.csv")
OUTPUT_CSV_FILE_PATH = os.getenv("OUTPUT_CSV_FILE_PATH", CSV_FILE_PATH)
ENABLE_DATA_CLEANING = os.getenv("ENABLE_DATA_CLEANING", "true").lower() == "true"
FILTER_QUERY = os.getenv("FILTER_QUERY", "")

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('monitor.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# HTML 内容缓存文件
CONTENT_CACHE_FILE = "html_content_cache.json"

# ========== 工具函数 ==========

def load_content_cache() -> Dict:
    """加载 HTML 内容缓存"""
    if os.path.exists(CONTENT_CACHE_FILE):
        try:
            with open(CONTENT_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"加载缓存文件失败: {e}")
            return {}
    return {}

def save_content_cache(cache: Dict):
    """保存 HTML 内容缓存"""
    try:
        with open(CONTENT_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"保存缓存文件失败: {e}")

def calculate_content_hash(content: str) -> str:
    """计算内容的 MD5 哈希值"""
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def extract_relevant_content(html: str) -> str:
    """
    提取包含"要項"的相关内容
    返回清洗后的文本用于比对
    """
    # 移除 HTML 标签
    text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<[^>]+>', ' ', text)

    # 解码 HTML 实体
    import html as html_module
    text = html_module.unescape(text)

    # 标准化空白字符
    text = re.sub(r'\s+', ' ', text).strip()

    # 查找包含"要項"的段落（前后各 800 字符，增加上下文）
    relevant_parts = []
    for match in re.finditer(r'要項', text):
        start = max(0, match.start() - 5000)
        end = min(len(text), match.end() + 5000)
        relevant_parts.append(text[start:end])

    if relevant_parts:
        logger.info(f"找到 {len(relevant_parts)} 处包含'要項'的内容")
        return '\n---\n'.join(relevant_parts)
    else:
        logger.warning("未找到'要項'相关内容")
        return ""

# ========== DeepSeek AI 分析 ==========

def analyze_changes_with_ai(old_content: str, new_content: str, school: str, major: str) -> Optional[Dict]:
    """
    使用 DeepSeek AI 分析内容变化，判断是否有要項相关的重大变更

    返回格式：
    {
        "has_significant_change": bool,  # 是否有重大变化
        "change_summary": str,           # 变化摘要
        "affected_fields": list,         # 影响的字段
        "severity": str                  # 严重程度：critical/important/minor
    }
    """
    if not DEEPSEEK_API_KEY:
        logger.error("DeepSeek API Key 未配置")
        return None

    try:
        # 设置环境变量
        os.environ["DEEPSEEK_API_KEY"] = DEEPSEEK_API_KEY
        os.environ["DEEPSEEK_API_BASE"] = DEEPSEEK_API_BASE

        # 构造提示词
        prompt = f"""
你是一个专业的日本大学招生信息变更分析助手。请对比以下两段内容，判断是否存在要項（招生要項）相关的重大变化。
注意：
1.如果是学部招生信息的变化则不予理会，我们关注的是大学院部分的招生信息变化
2.如果是文科相关的专业的变化也不予理会，我们主要关注情報、電気、機械方面的专业
3.尽量尽量 严格的判定一下，我希望是真的有那种极其重大的变化你才要通知我，清晰的了解到这些官网本身杂音就很多，经常会产生无足轻重的小变化

学校：{school}
专攻：{major}

旧内容：
{old_content}

新内容：
{new_content}

请重点关注以下方面的变化：
1. 出愿期間（申请时间）- 开始日期、截止日期
2. 募集人員（招生人数）
3. 英語外部スコア要件（英语成绩要求）
4. 検定料（报名费）
5. 合格発表日（合格发表日期）
6. 考试科目、考试内容
7. 出愿材料要求
8. 或者要項的更新，重点关注各种新出现的文件相关的链接

判断标准：
- critical（紧急）：申请截止日期、考试日期等时间敏感信息变化
- important（重要）：招生人数、成绩要求、报名费等核心条件变化
- minor（次要）：措辞调整、格式变化、无关紧要的内容

请以 JSON 格式返回分析结果：
{{
  "has_significant_change": true/false,
  "change_summary": "简要说明主要变化（中文，1-2句话）",
  "affected_fields": ["变化的字段列表"],
  "severity": "critical/important/minor",
  "details": "详细变化说明（中文）"
}}

注意：
- 如果没有实质性变化（如只是页面布局、导航栏等无关内容变化），请返回 has_significant_change: false
- 只返回 JSON，不要其他解释
"""

        logger.info("正在调用 DeepSeek API 分析内容变化...")

        response = completion(
            model="deepseek/deepseek-chat",
            messages=[
                {"role": "system", "content": "你是一个专业的招生信息变更分析助手，只返回 JSON 格式的分析结果。"},
                {"role": "user", "content": prompt}
            ],
            api_base=DEEPSEEK_API_BASE,
            api_key=DEEPSEEK_API_KEY,
            temperature=0.1
        )

        result_text = response.choices[0].message.content.strip()
        logger.info(f"AI 分析结果: {result_text[:300]}...")

        # 提取 JSON
        json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
        if json_match:
            analysis = json.loads(json_match.group(0))
            logger.info(f"AI 判断：{'有重大变化' if analysis.get('has_significant_change') else '无重大变化'}")
            return analysis
        else:
            logger.error(f"AI 返回格式错误: {result_text}")
            return None

    except Exception as e:
        logger.error(f"AI 分析异常: {e}", exc_info=True)
        return None

# ========== 钉钉通知 ==========

def send_dingtalk_notification(message: str) -> bool:
    """发送钉钉 Webhook 通知"""
    if not DINGTALK_WEBHOOK:
        logger.warning("钉钉 Webhook 未配置，跳过通知")
        logger.info(f"【模拟通知】\n{message}")
        return False

    try:
        payload = {
            "msgtype": "text",
            "text": {
                "content": message
            }
        }
        response = requests.post(
            DINGTALK_WEBHOOK,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        result = response.json()
        if result.get("errcode") == 0:
            logger.info("钉钉通知发送成功")
            return True
        else:
            logger.error(f"钉钉通知发送失败: {result}")
            return False
    except Exception as e:
        logger.error(f"钉钉通知发送异常: {e}")
        return False

# ========== 数据读取/写入 ==========

def read_csv_table() -> pd.DataFrame:
    """从 CSV 文件读取表格数据"""
    try:
        if not os.path.exists(CSV_FILE_PATH):
            logger.error(f"CSV 文件不存在: {CSV_FILE_PATH}")
            return pd.DataFrame()

        df = pd.read_csv(CSV_FILE_PATH, encoding='utf-8-sig')
        logger.info(f"从 CSV 读取 {len(df)} 行数据")

        # 根据配置决定是否清洗数据
        if ENABLE_DATA_CLEANING:
            # 确保必要的列存在
            required_columns = ['学校', '専攻・コース', '官网链接']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                logger.warning(f"缺少必要列: {missing_columns}")
                # 如果缺少必要列，可能无法正确去重，但尽量继续
            else:
                # make sure 学校,研究科,専攻・コース,官网链接 unique
                df = df.drop_duplicates(subset=['学校', '専攻・コース', '官网链接'])
        else:
            logger.info("数据清洗已禁用 (ENABLE_DATA_CLEANING=false)")

        return df
    except Exception as e:
        logger.error(f"读取 CSV 文件失败: {e}")
        return pd.DataFrame()

def update_csv_row(df: pd.DataFrame, row_index: int, status: str, message: str, severity: str = ""):
    """更新 CSV 文件中某行的状态"""
    try:
        # 确保列存在
        if '状态' not in df.columns:
            df['状态'] = ''
        if '变更说明' not in df.columns:
            df['变更说明'] = ''
        if '严重程度' not in df.columns:
            df['严重程度'] = ''
        if '最后检查时间' not in df.columns:
            df['最后检查时间'] = ''

        df.at[row_index, '状态'] = status
        df.at[row_index, '变更说明'] = message
        df.at[row_index, '严重程度'] = severity
        df.at[row_index, '最后检查时间'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # 保存回文件
        df.to_csv(OUTPUT_CSV_FILE_PATH, index=False, encoding='utf-8-sig')
        logger.info(f"已更新第 {row_index} 行：状态={status}, 严重程度={severity}")
    except Exception as e:
        logger.error(f"更新 CSV 文件失败: {e}")

# ========== 爬虫抓取 ==========

def fetch_webpage_content(url: str, max_retries: int = 3) -> Optional[str]:
    """抓取网页 HTML 内容"""
    for attempt in range(max_retries):
        try:
            logger.info(f"正在抓取 URL: {url} (尝试 {attempt+1}/{max_retries})")
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'ja,en-US;q=0.7,en;q=0.3',
            }
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()

            # 尝试检测编码
            if response.encoding:
                response.encoding = response.apparent_encoding

            content = response.text
            logger.info(f"成功抓取内容，长度: {len(content)} 字符")
            return content

        except requests.exceptions.RequestException as e:
            logger.error(f"抓取失败 (尝试 {attempt+1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                sleep_time = 2 ** attempt
                logger.info(f"等待 {sleep_time} 秒后重试...")
                time.sleep(sleep_time)
        except Exception as e:
            logger.error(f"未知错误: {e}")
            break

    return None

def fetch_pdf_content(url: str) -> Optional[str]:
    """抓取并解析 PDF 内容"""
    try:
        logger.info(f"正在抓取 PDF: {url}")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()

        import pdfplumber
        import io

        pdf_content = ""
        with pdfplumber.open(io.BytesIO(response.content)) as pdf:
            for i, page in enumerate(pdf.pages[:20]):  # 限制前20页
                text = page.extract_text() or ""
                pdf_content += f"\n--- Page {i+1} ---\n{text}"

        logger.info(f"PDF 解析完成，共提取 {len(pdf_content)} 字符")
        return pdf_content

    except ImportError:
        logger.error("未安装 pdfplumber，无法解析 PDF")
        return None
    except Exception as e:
        logger.error(f"PDF 解析失败: {e}")
        return None

# ========== 主处理逻辑 ==========

def process_row(row_data: Dict, row_index: int, content_cache: Dict, df: pd.DataFrame) -> bool:
    """
    处理单行数据，检测内容变化并使用 AI 分析
    返回：是否有重大变更
    """
    school = str(row_data.get('学校', '')).strip()
    major = str(row_data.get('専攻・コース', '')).strip()
    url = str(row_data.get('官网链接', '')).strip()

    logger.info(f"\n{'='*80}")
    logger.info(f"处理第 {row_index} 行: {school} - {major}")
    logger.info(f"URL: {url}")
    logger.info(f"{'='*80}")

    if not url or url == 'nan':
        logger.warning(f"第 {row_index} 行缺少官网链接，跳过")
        return False

    # 生成缓存键
    cache_key = f"{school}|{major}|{url}"

    # 1. 抓取内容
    if url.lower().endswith('.pdf'):
        content = fetch_pdf_content(url)
    else:
        content = fetch_webpage_content(url)

    if not content:
        logger.error(f"无法抓取 URL: {url}")
        update_csv_row(df, row_index, "抓取失败", f"无法访问链接 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return False

    # 2. 提取相关内容（包含"要項"的部分）
    relevant_content = extract_relevant_content(content)

    if not relevant_content:
        logger.warning("未找到'要項'相关内容，使用全文")
        relevant_content = content

    # 3. 计算内容哈希
    content_hash = calculate_content_hash(relevant_content)
    logger.info(f"内容哈希: {content_hash}")

    # 4. 检查是否有变化
    if cache_key in content_cache:
        cached_data = content_cache[cache_key]
        old_hash = cached_data.get('hash', '')
        old_content = cached_data.get('content_preview', '')
        last_check = cached_data.get('last_check', '')

        logger.info(f"上次检查: {last_check}")
        logger.info(f"上次哈希: {old_hash}")

        if old_hash == content_hash:
            logger.info("内容未变化 ✓")
            update_csv_row(df, row_index, "正常", f"未检测到变化 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

            # 更新检查时间
            content_cache[cache_key]['last_check'] = datetime.now().isoformat()
            return False
        else:
            logger.warning("检测到内容变化，调用 AI 分析...")

            # 5. 使用 AI 分析变化
            analysis = analyze_changes_with_ai(old_content, relevant_content, school, major)

            if not analysis:
                logger.error("AI 分析失败，按普通变更处理")
                # 仍然发送通知
                message = f"""
【要項内容变更通知】（AI 分析失败）

学校：{school}
专攻：{major}
官网：{url}

检测时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
变更说明：页面中包含"要項"的内容发生了变化，但 AI 分析失败

请手动访问官网确认具体变更内容。
                """.strip()

                send_dingtalk_notification(message)
                update_csv_row(df, row_index, "已变更", "内容变化（AI分析失败）", "unknown")

                # 更新缓存
                content_cache[cache_key] = {
                    'hash': content_hash,
                    'last_check': datetime.now().isoformat(),
                    'content_preview': relevant_content[:2000]
                }
                return True

            # 6. 根据 AI 分析结果决定是否通知
            if analysis.get('has_significant_change', False):
                severity = analysis.get('severity', 'unknown')
                change_summary = analysis.get('change_summary', '未知变化')
                affected_fields = analysis.get('affected_fields', [])
                details = analysis.get('details', '')

                # 严重程度标识
                severity_emoji = {
                    'critical': '🔴 紧急',
                    'important': '🟡 重要',
                    'minor': '🟢 次要'
                }.get(severity, '⚪ 未知')

                # 7. 发送通知
                message = f"""
【要項重大变更通知】

严重程度：{severity_emoji}
学校：{school}
专攻：{major}
官网：{url}

变更摘要：{change_summary}

影响字段：{', '.join(affected_fields) if affected_fields else '未明确'}

详细说明：
{details}

检测时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

请立即访问官网确认！
                """.strip()

                logger.info(f"\n发送通知:\n{message}\n")
                send_dingtalk_notification(message)

                # 8. 更新缓存和 CSV
                content_cache[cache_key] = {
                    'hash': content_hash,
                    'last_check': datetime.now().isoformat(),
                    'content_preview': relevant_content[:2000]
                }
                update_csv_row(df, row_index, "已变更", change_summary, severity)

                return True
            else:
                # AI 判断无重大变化
                logger.info("AI 判断：无重大变化，不发送通知")
                update_csv_row(
                    df, row_index, "正常",
                    f"内容有变化但无重大影响 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )

                # 更新缓存
                content_cache[cache_key] = {
                    'hash': content_hash,
                    'last_check': datetime.now().isoformat(),
                    'content_preview': relevant_content[:2000]
                }
                return False
    else:
        # 首次检查，建立基线
        logger.info("首次检查，建立内容基线")
        content_cache[cache_key] = {
            'hash': content_hash,
            'last_check': datetime.now().isoformat(),
            'content_preview': relevant_content[:2000]
        }
        update_csv_row(df, row_index, "已建立基线", f"首次检查 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return False

# ========== 主函数 ==========

def main():
    """主流程"""
    logger.info("\n" + "="*100)
    logger.info("开始执行招生信息变更监控任务（AI 智能分析模式）")
    logger.info("="*100 + "\n")

    # 检查配置
    if not DEEPSEEK_API_KEY:
        logger.error("错误：未配置 DEEPSEEK_API_KEY，请在 .env 文件中设置")
        return

    # 加载内容缓存
    content_cache = load_content_cache()
    logger.info(f"已加载 {len(content_cache)} 条内容缓存记录")

    # 读取表格数据
    df = read_csv_table()
    if df.empty:
        logger.error("表格数据为空，退出")
        return

    logger.info(f"共读取 {len(df)} 行数据\n")

    # 立即保存清洗后的数据（去重）
    if ENABLE_DATA_CLEANING:
        try:
            df.to_csv(OUTPUT_CSV_FILE_PATH, index=False, encoding='utf-8-sig')
            logger.info(f"已保存清洗后的数据（去重）到 CSV 文件: {OUTPUT_CSV_FILE_PATH}")
        except Exception as e:
            logger.error(f"保存清洗后的 CSV 失败: {e}")

    # 应用筛选条件（仅用于决定处理哪些行，不影响 CSV 保存）
    target_df = df.copy()
    if FILTER_QUERY:
        try:
            original_count = len(target_df)
            target_df = target_df.query(FILTER_QUERY)
            logger.info(f"已应用筛选条件: {FILTER_QUERY} (筛选前: {original_count}, 筛选后: {len(target_df)})")
        except Exception as e:
            logger.error(f"筛选条件错误: {e}")
    elif ENABLE_DATA_CLEANING and '考试时期' in df.columns:
        # 默认行为：如果有“考试时期”列，只看“冬入”
        logger.info("未设置 FILTER_QUERY，使用默认筛选：考试时期 == '冬入'")
        target_df = target_df[target_df['考试时期'] == '冬入']

    # 逐行处理（可选测试模式）
    total_changes = 0
    test_mode = os.getenv("TEST_MODE", "false").lower() == "true"
    max_rows = int(os.getenv("MAX_ROWS", "5")) if test_mode else len(target_df)

    if test_mode:
        logger.info(f"测试模式：只处理前 {max_rows} 行\n")

    # 注意：这里遍历的是 target_df，但传入 process_row 的是完整的 df
    # 这样 update_csv_row 更新的是完整的 df，并写回完整的 CSV
    for index, row in target_df.iterrows():
        if total_changes >= max_rows and test_mode: # 修正测试模式计数逻辑
             break # 简单起见，测试模式只处理 max_rows 个目标行
        
        # 实际上 iterrows 返回的 index 是原始 df 的 index（除非 reset_index 过了）
        # 我们没有 reset_index，所以 index 是安全的

        # 计数器控制测试模式
        processed_count = 0
        if test_mode and processed_count >= max_rows:
            break
        processed_count += 1

        try:
            has_change = process_row(row.to_dict(), index, content_cache, df)
            if has_change:
                total_changes += 1
                logger.info(f"第 {index} 行检测到重大变更 🔔")

            # 避免请求过快
            if index < min(max_rows, len(df)) - 1:
                sleep_time = 5  # AI 调用需要更长间隔
                logger.info(f"等待 {sleep_time} 秒...\n")
                time.sleep(sleep_time)

        except Exception as e:
            logger.error(f"处理第 {index} 行时出错: {e}", exc_info=True)
            continue

    # 保存缓存
    save_content_cache(content_cache)
    logger.info(f"\n已保存 {len(content_cache)} 条内容缓存记录")

    logger.info("\n" + "="*100)
    logger.info(f"监控任务完成，共检测到 {total_changes} 条重大变更")
    logger.info("="*100 + "\n")

if __name__ == "__main__":
    main()
