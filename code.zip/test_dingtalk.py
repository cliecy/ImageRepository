
import os
import requests
import json
from dotenv import load_dotenv

def test_dingtalk():
    print("Loading environment variables...")
    load_dotenv()
    
    webhook = os.getenv("DINGTALK_WEBHOOK")
    
    if not webhook:
        print("❌ Error: DINGTALK_WEBHOOK environment variable is not set.")
        return
    
    print(f"Webhook URL found: {webhook[:20]}...")
    
    print("Sending test notification...")
    try:
        payload = {
            "msgtype": "text",
            "text": {
                "content": "【测试】这是一个来自 spiderCheckProject 的测试通知。\n如果看到这条消息，说明钉钉通知配置正确。 募集要项"
            }
        }
        response = requests.post(
            webhook,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        print(f"Response: {json.dumps(result, ensure_ascii=False)}")
        
        if result.get("errcode") == 0:
            print("✅ Success: Notification sent successfully.")
        else:
            print(f"❌ Failed: API returned error code {result.get('errcode')}")
            
    except Exception as e:
        print(f"❌ Exception: {e}")

if __name__ == "__main__":
    test_dingtalk()
